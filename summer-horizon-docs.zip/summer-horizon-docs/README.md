# Summer Horizon — Documentation FiveM

Site statique en HTML, CSS et JavaScript, sans framework ni dépendance externe. Conçu pour être hébergé gratuitement sur GitHub Pages.

## Fichiers

- `index.html` : structure et contenu des pages
- `style.css` : thème sombre et doré, responsive ordinateur/mobile
- `script.js` : navigation, recherche, menu mobile et bouton de copie
- `assets/favicon.svg` : icône de l'onglet

## Personnalisation à faire avant publication

Ouvrez `index.html` et remplacez :
- Les liens `https://discord.com/` par le lien d'invitation officiel de votre Discord.
- `VOTRE_CODE_SERVEUR` par le vrai code Cfx.re de Summer Horizon.
- Les règles provisoires de la page « Règlement » par votre règlement officiel.
- Les commandes d'exemple de la page « Commandes utiles » par les commandes réellement activées sur votre serveur.
- Le statut de whitelist dans la FAQ, selon la configuration actuelle.

Palette :
- Or : `#D4A64E`
- Or clair : `#F6DA97`
- Fond : `#11100E`

## Tester en local

Double-cliquez sur `index.html` pour l'ouvrir dans votre navigateur. Pour tester plus fidèlement, ouvrez le dossier dans VS Code et utilisez une extension de serveur local (facultatif).

## Publier gratuitement avec GitHub Pages

1. Créez ou connectez-vous à un compte sur https://github.com/.
2. Cliquez sur **New repository**.
3. Donnez-lui le nom `summer-horizon-docs`. Choisissez **Public**, puis créez le dépôt.
4. Dans le dépôt, cliquez sur **Add file → Upload files**.
5. Décompressez l'archive téléchargée, puis glissez les fichiers et dossiers (`index.html`, `style.css`, `script.js`, `assets`, `README.md`) dans GitHub. Il faut que `index.html` soit à la racine du dépôt, pas dans un sous-dossier.
6. Cliquez sur **Commit changes**.
7. Ouvrez **Settings → Pages**.
8. Dans **Build and deployment**, choisissez **Deploy from a branch**.
9. Sélectionnez la branche `main` et le dossier `/(root)`, puis cliquez sur **Save**.
10. Attendez quelques minutes. L'adresse sera généralement `https://VOTRE-PSEUDO.github.io/summer-horizon-docs/`.

À chaque modification ultérieure, envoyez les nouveaux fichiers sur GitHub : Pages republiera le site automatiquement.

## Important

Le site fourni est un modèle de départ : les liens Discord, le code de connexion, les règles et les commandes doivent être validés et remplacés avant de le partager aux joueurs. GitHub Pages héberge le site statique ; il ne fournit pas de backend pour comptes, tickets privés ou données confidentielles.
