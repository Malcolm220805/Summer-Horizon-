(() => {
  const pages = {
    accueil: { title: "Accueil", keywords: "présentation bienvenue summer horizon" },
    demarrer: { title: "Bien démarrer", keywords: "installation fivem connexion nouveau joueur gta" },
    reglement: { title: "Règlement", keywords: "règles roleplay rp rdm vdm fear pain sanctions" },
    commandes: { title: "Commandes utiles", keywords: "commandes raccourcis me do report ooc" },
    faq: { title: "FAQ", keywords: "questions aide support discord bug whitelist" }
  };
  const navButtons = [...document.querySelectorAll("[data-page]")];
  const views = [...document.querySelectorAll(".page-view")];
  const crumbCurrent = document.getElementById("crumbCurrent");
  const sidebar = document.getElementById("sidebar");
  const overlay = document.getElementById("mobileOverlay");
  const searchInput = document.getElementById("searchInput");
  const searchResults = document.getElementById("searchResults");
  const toast = document.getElementById("toast");
  let toastTimer;

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
  }
  function goToPage(key, updateHash = true) {
    if (!pages[key]) key = "accueil";
    views.forEach(view => { view.hidden = view.id !== `page-${key}`; });
    navButtons.forEach(button => button.classList.toggle("active", button.dataset.page === key));
    crumbCurrent.textContent = pages[key].title;
    if (updateHash) history.replaceState(null, "", `#${key}`);
    closeMobileMenu();
    searchResults.hidden = true;
    searchInput.blur();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function closeMobileMenu() { sidebar.classList.remove("open"); overlay.classList.remove("show"); }
  function openMobileMenu() { sidebar.classList.add("open"); overlay.classList.add("show"); }
  navButtons.forEach(button => button.addEventListener("click", () => goToPage(button.dataset.page)));
  document.querySelectorAll("[data-goto]").forEach(button => button.addEventListener("click", () => goToPage(button.dataset.goto)));
  document.getElementById("mobileMenu").addEventListener("click", openMobileMenu);
  overlay.addEventListener("click", closeMobileMenu);

  function renderSearch(query) {
    const q = query.trim().toLocaleLowerCase("fr");
    if (!q) { searchResults.hidden = true; searchResults.innerHTML = ""; return; }
    const results = Object.entries(pages).filter(([key, page]) => `${page.title} ${page.keywords}`.toLocaleLowerCase("fr").includes(q));
    searchResults.innerHTML = "";
    if (!results.length) {
      const empty = document.createElement("div");
      empty.className = "no-results";
      empty.textContent = "Aucun résultat. Essayez un autre mot-clé.";
      searchResults.appendChild(empty);
    } else {
      results.forEach(([key, page]) => {
        const button = document.createElement("button");
        button.className = "search-result";
        button.type = "button";
        const strong = document.createElement("strong");
        strong.textContent = page.title;
        const small = document.createElement("small");
        small.textContent = `Ouvrir la page · ${page.keywords.split(" ").slice(0, 5).join(", ")}`;
        button.append(strong, small);
        button.addEventListener("click", () => goToPage(key));
        searchResults.appendChild(button);
      });
    }
    searchResults.hidden = false;
  }
  searchInput.addEventListener("input", () => renderSearch(searchInput.value));
  document.addEventListener("click", event => {
    if (!event.target.closest(".search-box") && !event.target.closest(".search-results")) searchResults.hidden = true;
  });
  document.addEventListener("keydown", event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
      event.preventDefault(); searchInput.focus(); searchInput.select();
    }
    if (event.key === "Escape") { searchResults.hidden = true; searchInput.blur(); closeMobileMenu(); }
  });
  document.querySelectorAll("[data-copy]").forEach(button => button.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(button.dataset.copy);
      showToast("Commande copiée !");
    } catch {
      showToast("Copie impossible : sélectionnez la commande manuellement.");
    }
  }));
  const initialPage = location.hash.replace("#", "");
  goToPage(pages[initialPage] ? initialPage : "accueil", false);
  window.addEventListener("hashchange", () => {
    const key = location.hash.replace("#", "");
    goToPage(pages[key] ? key : "accueil", false);
  });
})();